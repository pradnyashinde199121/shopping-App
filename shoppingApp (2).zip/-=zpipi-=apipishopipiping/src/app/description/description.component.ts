import { Component, OnInit } from '@angular/core';
import {ShopProductsService} from '../shop-products.service';
import { isNullOrUndefined } from 'util';
@Component({
  selector: 'app-description',
  templateUrl: './description.component.html',
  styleUrls: ['./description.component.css']
})
export class DescriptionComponent implements OnInit {
  descriptionData:any;
  currentProduct:any=[];
  //count:number=1;
  subTotal:number;
  countZero:boolean=false;
  showEmojiPicker = false;
  sets = [
    'native',
    'google',
    'twitter',
    'facebook',
    'emojione',
    'apple',
    'messenger'
  ]
  set = 'twitter';
  message = '';
  name:string;
  email:string;
  msg:any;
  ratingCount:number;
  currentContact:any={};
  sendMsgs:any=[]
  total:number;
  avgRatingCount: number;
  constructor( private shopProductsService :ShopProductsService) { }

  ngOnInit() {
  this.shopProductsService.obsProductDescription.subscribe(x=>{
    this.descriptionData=x;
     this.descriptionData.quantity=this.descriptionData.quantity
   this.subTotal=this.descriptionData.price;
  });
  this.shopProductsService.cartAddedProduct.subscribe(res=>{
    this.currentProduct=res;
  });

  }
  addCart(descriptionData){
    if(isNullOrUndefined(this.currentProduct)){
      this.currentProduct= [];
    }
   this.currentProduct.push(descriptionData); 
   this.shopProductsService.addCartData(this.currentProduct);
  }
  
  icrDcrUpdate(){
    this.subTotal=this.descriptionData.price * this.descriptionData.quantity;
  }
  incrQuantity(){
    this.descriptionData.quantity++;
    this.icrDcrUpdate();
  }
  decrQuantity(i){
    this.descriptionData.quantity--;
    if(this.descriptionData.quantity==0){
      this.descriptionData='';
      this.countZero=true;
    }
    this.icrDcrUpdate();
  }

  toggleEmojiPicker() {
    console.log(this.showEmojiPicker);
        this.showEmojiPicker = !this.showEmojiPicker;
  }

  addEmoji(event) {
    console.log(this.message)
    const { message } = this;
    console.log(message);
    console.log(`${event.emoji.native}`)
    const text = `${message}${event.emoji.native}`;

    this.message = text;
    // this.showEmojiPicker = false;
  }

  onFocus() {
    console.log('focus');
    this.showEmojiPicker = false;
  }
  onBlur() {
    console.log('onblur')
 }
 sendMsg(){
   this.msg=this.message;
   this.message=''; 
   this.CurrentContact();
   this.avgRating(this.sendMsgs);
 }
 starRatingCount(event){
 this.ratingCount=event.rating;
 }
 CurrentContact(){
  this.currentContact={};
   this.currentContact.Name=this.name;
   this.currentContact.Email =this.email;
   this.currentContact.Rating =this.ratingCount;
   this.currentContact.Msg =this.msg;
   this.sendMsgs.push(this.currentContact );
   this.name='';
   this.email='';
 
 }
 avgRating( sendMsgs){
  this.total=0;
  sendMsgs.forEach(element => {
  this.total=element.Rating + this.total;
});
this.avgRatingCount= this.total/this.sendMsgs.length;
}
}
