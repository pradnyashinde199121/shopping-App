import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { GalleryComponent } from './gallery/gallery.component';
import { FeaturesComponent } from './features/features.component';
import { ReviewsComponent } from './reviews/reviews.component';
import { ShopComponent } from './shop/shop.component';
import { CartComponent } from './cart/cart.component';
import { DescriptionComponent } from './description/description.component';
const routes: Routes = [{path:'home', component:HomeComponent},
{path:'gallery', component:GalleryComponent},
{path:'features', component:FeaturesComponent},
{path:'reviews', component:ReviewsComponent},
{path:'shop', component:ShopComponent},
{path:'cart', component:CartComponent},
{path:'description', component:DescriptionComponent},];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
