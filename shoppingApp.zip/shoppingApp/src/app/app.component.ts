import { Component } from '@angular/core';
import {ShopProductsService} from './shop-products.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'shoppingWeb';
  count:number;
  cartData:any=[];
  constructor(private shopProductsService :ShopProductsService) { }
  ngOnInit() {
    this.shopProductsService.cartAddedProduct.subscribe(res=>{
      
      this.cartData=res
      this.getCartLength(this.cartData);
    });
    
  }
  getCartLength(data){
    if(data == null){
      this.count=0;
    }
    else
    {
      this.count=data.length;
    }
  }
}
