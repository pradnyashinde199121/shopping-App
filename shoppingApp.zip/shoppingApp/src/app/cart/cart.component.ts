import { Component, OnInit } from '@angular/core';
import {ShopProductsService} from '../shop-products.service';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartData:any=[];
  subTotal:number;
  total:number=0;
  countZero:boolean=false;
  constructor(private shopProductsService :ShopProductsService) { }

  ngOnInit() {
    this.shopProductsService.cartAddedProduct.subscribe(res=>{
      this.cartData=res;
      this.calculateTotal(this.cartData);
      
    });
    this.cartData.quantity=this.cartData.quantity
    this.subTotal=this.cartData.price;
  }

  deleteProduct(i){
    this.cartData.splice(i,1);
    this.shopProductsService.addCartData(this.cartData);
  }
  incrQuantity(value){
   const index = this.cartData.findIndex(x=>x.id ==value.id);
   this.cartData[index].quantity++;
   this.shopProductsService.addCartData(this.cartData);
  
  }
  decrQuantity(value){
    const index = this.cartData.findIndex(x=>x.id ==value.id);
    this.cartData[index].quantity--;
    if(this.cartData[index].quantity==0){
      this.cartData.splice(index,1);
      this.shopProductsService.addCartData(this.cartData);
    }
    this.shopProductsService.addCartData(this.cartData);
    if(this.cartData==0){this.countZero=true;}
    
  }
  calculateTotal( cartData){
    this.total=0;
cartData.forEach((element: { price: number; quantity: number; }) => {
  
  this.total=element.price*element.quantity+ this.total ;

});
  }
}