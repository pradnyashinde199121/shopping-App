import { Component, OnInit } from '@angular/core';
import {ShopProductsService} from '../shop-products.service';
import { isNullOrUndefined } from 'util';
@Component({
  selector: 'app-description',
  templateUrl: './description.component.html',
  styleUrls: ['./description.component.css']
})
export class DescriptionComponent implements OnInit {
  descriptionData:any;
  currentProduct:any=[];
  //count:number=1;
  subTotal:number;
  countZero:boolean=false;
  constructor( private shopProductsService :ShopProductsService) { }

  ngOnInit() {
  this.shopProductsService.obsProductDescription.subscribe(x=>this.descriptionData=x);
  this.shopProductsService.cartAddedProduct.subscribe(res=>{
    this.currentProduct=res;
  });
  this.descriptionData.quantity=this.descriptionData.quantity
  this.subTotal=this.descriptionData.price;
  }
  addCart(descriptionData){
    if(isNullOrUndefined(this.currentProduct)){
      this.currentProduct= [];
    }
   this.currentProduct.push(descriptionData); 
   this.shopProductsService.addCartData(this.currentProduct);
  }
  
  incrQuantity(){
    this.descriptionData.quantity++;
    this.subTotal=this.descriptionData.price * this.descriptionData.quantity;
  }
  decrQuantity(i){
    this.descriptionData.quantity--;
    if(this.descriptionData.quantity==0){
      this.descriptionData='';
      this.countZero=true;
    }
    this.subTotal=this.descriptionData.price * this.descriptionData.quantity;
  }

}
