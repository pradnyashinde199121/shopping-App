import { Injectable } from '@angular/core';
import { HttpClient } from  '@angular/common/http';  
import { Observable } from 'rxjs';
import { BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ShopProductsService {
 url:string="/assets/products.json";
  constructor( private httpClient: HttpClient) { }
  private cartProduct = new BehaviorSubject(null);
  cartAddedProduct = this.cartProduct.asObservable();
  private descriptionProduct = new BehaviorSubject(null);
  obsProductDescription = this.descriptionProduct.asObservable();

  getProducts():Observable<any>{
    return this.httpClient.get<any>(this.url);
  }
  addCartData(currentProduct){
    this.cartProduct.next(currentProduct);
  }
  descriptionAddService(product){
    this.descriptionProduct.next(product);
  }
}
