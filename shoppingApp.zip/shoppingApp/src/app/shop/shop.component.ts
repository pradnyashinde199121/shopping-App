import { Component, OnInit, ViewChild ,ChangeDetectorRef } from '@angular/core';
import {ShopProductsService} from '../shop-products.service';
import { isNullOrUndefined } from 'util';
import { Options, LabelType } from 'ng5-slider';
import { MatTableDataSource, MatSort,MatPaginator } from '@angular/material';
import { Observable } from 'rxjs';
export interface SmartWatch {
  id:number
  img: string;
  colour: string;
  price: number;
  quantity: number;
  type:string;}
@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css']
})
export class ShopComponent implements OnInit {
  
  data:any[]=[];
  currentProduct:any=[];
  showTicks = false;
  thumbLabel = false;
  value = 0;
  tickInterval = 500;
  autoTicks: any;
  flag:boolean=true;
  cartData:any=[];
  totalvalue=0;
  minValue: number = 1;
  maxValue: number = 30;
  options: Options = {
    floor: 0,
    ceil: 30,
    translate: (value: number, label: LabelType): string => {
      switch (label) {
        case LabelType.Low:
          return '<b>Min price:' + value;
        case LabelType.High:
          return '<b>Max price:' + value;
        default:
          return '$' + value;
      }
    }
  };
  getSliderTickInterval(): number | 'auto' {
    if (this.showTicks) {
      return this.autoTicks ? 'auto' : this.tickInterval;
    }

    return 0;
  }
  @ViewChild(MatPaginator,{static: true}) paginator: MatPaginator;
  obs: Observable<any>;
  dataSource: MatTableDataSource<any> = new MatTableDataSource<any>(this.data);
 
  filteredValues:any = {
    id:'',
    price: '', 
    colour: '', 
  };
  constructor(private shopProductsService :ShopProductsService, private changeDetectorRef: ChangeDetectorRef) { }

  ngOnInit() {
    this.shopProductsService.getProducts().subscribe(res=> {
      this.data=res;  
      this.dataSource =  new MatTableDataSource<any>(this.data);   
      this.changeDetectorRef.detectChanges();
      this.dataSource.paginator = this.paginator;
      this.dataSource.filterPredicate = this.customFilterPredicate(); //filter for multiple value
      this.obs = this.dataSource.connect();     
      });
    this.shopProductsService.cartAddedProduct.subscribe(res=>{
        this.currentProduct=res;
      });
      this.data = this.data.sort((low, high) => low.Price - high.Price);
  }
  addCart(product){
    if(isNullOrUndefined(this.currentProduct)){
      this.currentProduct= [];
    }
   this.currentProduct.push(product); 
   this.shopProductsService.addCartData(this.currentProduct);
  }
  descriptionParent(product){
 this.shopProductsService.descriptionAddService(product);
  }

  customFilterPredicate() {
    const myFilterPredicate = (data:SmartWatch, filter: string): boolean => {
      let searchString = JSON.parse(filter);
      return data.colour.toString().trim().toLowerCase().indexOf(searchString.colour.toLowerCase()) !== -1 && data.price >= this.minValue && data.price <= this.maxValue;
         
    }
    return myFilterPredicate; 
    }
  updateFilter() {
    this.dataSource.filter = JSON.stringify(this.filteredValues);
  }

  changeFilter(event){
    if(event.target.value === "price"){
      this.flag = true;
    }
   else {
      this.flag = false;
    }

  }
  sort(event: any) {
    switch (event.target.value) {
      case "Low":
        {
          this.data = this.data.sort((low, high) => low.price - high.price);
          break;
        }

      case "High":
        {
          this.data = this.data.sort((low, high) => high.price - low.price);
          break;
        }

      default: {
        this.data = this.data.sort((low, high) => low.price - high.price);
        break;
      }

    }
    this.dataSource =  new MatTableDataSource<any>(this.data);   
      this.changeDetectorRef.detectChanges();
      this.dataSource.paginator = this.paginator;
      this.dataSource.filterPredicate = this.customFilterPredicate(); //filter for multiple value
      this.obs = this.dataSource.connect(); 
    return this.data;
    

  }

}
